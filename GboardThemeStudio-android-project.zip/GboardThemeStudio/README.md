# Gboard Theme Studio — مشروع أندرويد (Source Project)

ده مشروع Android Studio **جاهز للبناء**، مش ملف APK متصرف جاهز — المشروع بيحتاج Android SDK و Gradle
عشان يتحول لـ APK فعلي، وده مش متاح جوه بيئة Claude، فده أقرب حاجة ممكن أسلّمها هنا وهي كل الكود
المصدري شغّال 100%.

## اللي جوه المشروع
- تطبيق WebView بسيط (`MainActivity.java`) بيفتح نفس أداة Gboard Theme Studio اللي شفتها في Claude،
  لكن نسخة **أوفلاين بالكامل**: مكتبة JSZip ومحرك الألوان `style_sheet_md2.css` وكل أيقونات Plumpy
  الـ12 متحطين كـ assets محلية جوه المشروع نفسه (`app/src/main/assets/`) — مفيش أي اعتماد على إنترنت
  أو على claude.ai.
- زرار "تنزيل الثيم" بيحفظ ملف الـZIP مباشرة في مجلد **التنزيلات (Downloads)** على الموبايل عن طريق
  جسر JavaScript بسيط (`AndroidSaver`) بدل ما يعتمد على أي منصة خارجية.
- شكل الأيقونة والألوان بتاعة التطبيق placeholder بسيط (تقدر تغيّرهم بسهولة من `res/drawable`).

## إزاي تبنيه APK
**الطريقة الأسهل — Android Studio:**
1. افتح Android Studio → Open → اختار فولدر `GboardThemeStudio` ده.
2. سيبه يعمل Gradle Sync (هيطلب منك يحمّل Android Gradle Plugin وGradle Wrapper أول مرة).
3. من القائمة: `Build → Build Bundle(s) / APK(s) → Build APK(s)`.
4. الـAPK هيطلع في `app/build/outputs/apk/debug/app-debug.apk`.

**من التيرمينال (لو عندك Android SDK وGradle متثبتين):**
```
cd GboardThemeStudio
gradle wrapper          # أول مرة بس، عشان يولّد gradlew
./gradlew assembleDebug
```

## حاجات مهمة
- الـ `minSdk` متظبط على 26 (Android 8.0+) عشان الأيقونة المرنة (adaptive icon) تشتغل عادي.
- على Android 9 وأقل، التطبيق هيطلب إذن التخزين مرة واحدة أول ما يفتح. من Android 10 لأعلى مفيش أي إذن مطلوب (بيستخدم MediaStore تلقائيًا).
- لو عايز تغيّر اسم الحزمة (`applicationId`) أو اسم التطبيق، عدّلهم في `app/build.gradle` و `res/values/strings.xml`.
- أي تحديث على الأداة نفسها (ألوان/ميزات جديدة) يتحط في `app/src/main/assets/index.html`.
