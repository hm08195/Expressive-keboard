# Keycraft — Plugin Builder

أداة ويب خفيفة (HTML/CSS/JS فقط، من غير أي framework أو build tools) لبناء ملفات
`plugin.json` الخاصة بتخصيصات كيبورد **Expressive Keyboard**، بواجهة نماذج سهلة بدل
كتابة الـ JSON يدويًا.

## المميزات

- تغطية كل أقسام ملف البلاجن: المعلومات الأساسية، actions، shortcuts، symbols،
  theme، settings، variants، skin (background / orbs / تنسيق كل زرار / chips).
- **استيراد ملف `plugin.json` موجود** وتعديله.
- **صندوق "متقدّم"**: أي حقل غير موجود في النموذج، تكتبه كـ JSON خام وهيتم دمجه فوق
  باقي الإعدادات تلقائيًا — يعني الأداة بتقبل أي تخصيص متاح في صيغة البلاجن حتى
  لو مش متمثّل بزرار جاهز في الواجهة.
- معاينة حيّة للـ JSON الناتج + تحميل مباشر أو نسخ.
- يعمل بدون إنترنت بعد أول تشغيل (PWA مع service worker).
- لا يعتمد على أي خط أو مكتبة خارجية، فيشتغل بشكل موثوق جوه WebView/APK.

## هيكل المشروع

```
index.html          نقطة الدخول
css/styles.css       التنسيق
js/app.js            كل منطق التطبيق
manifest.json         بيانات PWA (اسم، أيقونة، ألوان)
service-worker.js    تخزين مؤقت للعمل أوفلاين
icons/               أيقونات التطبيق (192px, 512px, 1024px)
```

## تجربة الملف محليًا

افتح `index.html` مباشرة في المتصفح، أو شغّل سيرفر محلي بسيط (أفضل لأن الـ
service worker محتاج http وليس `file://`):

```bash
cd keycraft
python3 -m http.server 8080
```

ثم افتح `http://localhost:8080` في المتصفح.

## رفعه على GitHub

```bash
git init
git add .
git commit -m "Initial commit: Keycraft plugin builder"
git branch -M main
git remote add origin <رابط الريبو بتاعك>
git push -u origin main
```

## تحويله إلى APK

المشروع مبني كـ **PWA عادي** (ملفات HTML/CSS/JS + manifest)، وده بيفتح أكتر من
طريق للتحويل لـ APK من غير ما تكتب كود Android بنفسك:

### الطريقة الأولى — PWA Builder (الأسهل)
1. فعّل GitHub Pages على الريبو (Settings → Pages) عشان ياخد رابط مباشر للموقع.
2. روح على [pwabuilder.com](https://www.pwabuilder.com) وحط رابط الـ GitHub Pages.
3. الأداة هتفحص الـ manifest والـ service worker تلقائيًا وتطلعلك خيار تنزيل
   **Android package (APK/AAB)** جاهز.

### الطريقة الثانية — أدوات تحويل HTML إلى APK
فيه أدوات (Desktop أو أونلاين) بتاخد مجلد الموقع كـ zip وتطلع APK مباشرة عن طريق
تغليفه في WebView (مثال: Website 2 APK Builder). ابحث عن أحدث نسخة من أي أداة
زي دي، لأن الخطوات والواجهة بتتغيّر مع الوقت.

### ملاحظة
زرار "تحميل plugin.json" بيستخدم تحميل ملفات عادي بالمتصفح (`<a download>`)،
وده بيشتغل تمام سواء التطبيق شغال كـ PWA أو متغلّف في WebView/APK عادي، من غير
احتياج لأي صلاحيات تخزين إضافية.

## تخصيص الشكل

الألوان كلها CSS variables في أول ملف `css/styles.css` (داخل `:root`)، لو حبيت
تغيّر لون الـ accent أو الخلفية يكفي تعدّل القيم هناك وهتنعكس على كل الواجهة.
