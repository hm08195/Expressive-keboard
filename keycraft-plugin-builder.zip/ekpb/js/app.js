(() => {
  "use strict";

  /* ---------------------------------------------------------
     State
  --------------------------------------------------------- */
  const state = {
    id: "", name: "", version: "1.0.0", author: "", description: "", icon: "",
    actions: [],
    shortcuts: [],
    symbols: [],
    theme: { seed: "#e8b24d", mode: "DARK", shape: "FLOWER_6", shapeCustom: "", accent: "#e8b24d", accentText: "#10161c" },
    settings: { keyHeight: 58, numberRow: true },
    variants: [],
    skin: {
      bg1: "#141b22", bg2: "#1c252e", angle: 135,
      orbs: [],
      keys: [],
      chipsMaterial: "glass", chipsTextColor: "#eef1f0"
    },
    advancedRaw: ""
  };

  let uidSeed = 1;
  const nextId = () => uidSeed++;

  /* ---------------------------------------------------------
     Small DOM helpers
  --------------------------------------------------------- */
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  function el(tag, cls, children) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (children) children.forEach(c => c && e.appendChild(c));
    return e;
  }
  function labeledInput(labelText, inputEl) {
    const wrap = el("label", "field");
    const span = el("span"); span.textContent = labelText;
    wrap.appendChild(span); wrap.appendChild(inputEl);
    return wrap;
  }
  function textInput(value, placeholder, onInput) {
    const i = document.createElement("input");
    i.type = "text"; i.value = value || ""; if (placeholder) i.placeholder = placeholder;
    i.addEventListener("input", () => onInput(i.value));
    return i;
  }
  function numberInput(value, onInput, opts = {}) {
    const i = document.createElement("input");
    i.type = "number"; i.value = value;
    if (opts.step != null) i.step = opts.step;
    if (opts.min != null) i.min = opts.min;
    if (opts.max != null) i.max = opts.max;
    i.addEventListener("input", () => onInput(parseFloat(i.value) || 0));
    return i;
  }
  function colorInput(value, onInput) {
    const i = document.createElement("input");
    i.type = "color"; i.value = value || "#000000";
    i.addEventListener("input", () => onInput(i.value));
    return i;
  }
  function selectInput(options, value, onInput) {
    const s = document.createElement("select");
    options.forEach(([val, label]) => {
      const o = document.createElement("option");
      o.value = val; o.textContent = label; if (val === value) o.selected = true;
      s.appendChild(o);
    });
    s.addEventListener("change", () => onInput(s.value));
    return s;
  }
  function checkboxField(labelText, checked, onInput) {
    const wrap = el("label", "field field-toggle");
    const span = el("span"); span.textContent = labelText;
    const i = document.createElement("input");
    i.type = "checkbox"; i.checked = !!checked;
    i.addEventListener("change", () => onInput(i.checked));
    wrap.appendChild(span); wrap.appendChild(i);
    return wrap;
  }
  function removeBtn(onClick) {
    const b = document.createElement("button");
    b.className = "remove-btn"; b.type = "button"; b.textContent = "×";
    b.addEventListener("click", onClick);
    return b;
  }
  function cardHead(indexLabel, onRemove) {
    const head = el("div", "card-head");
    const idx = el("span", "index"); idx.textContent = indexLabel;
    head.appendChild(idx); head.appendChild(removeBtn(onRemove));
    return head;
  }

  /* ---------------------------------------------------------
     Actions list
  --------------------------------------------------------- */
  function renderActions() {
    const list = $("#actionsList"); list.innerHTML = "";
    state.actions.forEach((a, i) => {
      const card = el("div", "card");
      card.appendChild(cardHead(`#${i + 1}`, () => { state.actions.splice(i, 1); renderActions(); updatePreview(); }));

      const grid = el("div", "field-grid");
      grid.appendChild(labeledInput("العنوان", textInput(a.title, "نسخ الكل", v => { a.title = v; updatePreview(); })));
      grid.appendChild(labeledInput("الأيقونة", textInput(a.icon, "@copy", v => { a.icon = v; updatePreview(); })));
      grid.appendChild(labeledInput("النوع", selectInput(
        [["insert", "insert — إدراج نص"], ["transform", "transform — تحويل النص"], ["key", "key — أمر نظام"]],
        a.type, v => { a.type = v; renderActions(); updatePreview(); }
      )));
      card.appendChild(grid);

      const grid2 = el("div", "field-grid");
      if (a.type === "insert") {
        const ta = document.createElement("textarea"); ta.rows = 2; ta.value = a.text || "";
        ta.placeholder = "النص اللي هيتكتب، تقدر تستخدم {newline} أو {date:yyyy-MM-dd}";
        ta.addEventListener("input", () => { a.text = ta.value; updatePreview(); });
        const w = el("label", "field field-wide"); const s = el("span"); s.textContent = "النص (text)";
        w.appendChild(s); w.appendChild(ta); grid2.appendChild(w);
      } else if (a.type === "transform") {
        grid2.appendChild(labeledInput("Transform", selectInput(
          [["calc", "calc"], ["wrap", "wrap"], ["upper", "upper"]],
          a.transform || "calc", v => { a.transform = v; renderActions(); updatePreview(); }
        )));
        if ((a.transform || "calc") === "wrap") {
          grid2.appendChild(labeledInput("Prefix", textInput(a.prefix, "(", v => { a.prefix = v; updatePreview(); })));
          grid2.appendChild(labeledInput("Suffix", textInput(a.suffix, ")", v => { a.suffix = v; updatePreview(); })));
        }
      } else if (a.type === "key") {
        grid2.appendChild(labeledInput("Key", textInput(a.key, "select_all", v => { a.key = v; updatePreview(); })));
      }
      card.appendChild(grid2);

      card.appendChild(checkboxField("تثبيت الزرار (pinned)", a.pinned, v => { a.pinned = v; updatePreview(); }));
      list.appendChild(card);
    });
  }
  $("#addActionBtn").addEventListener("click", () => {
    state.actions.push({ id: nextId(), title: "", icon: "", type: "insert", text: "", transform: "calc", prefix: "", suffix: "", key: "", pinned: false });
    renderActions(); updatePreview();
  });

  /* ---------------------------------------------------------
     Shortcuts list
  --------------------------------------------------------- */
  function renderShortcuts() {
    const list = $("#shortcutsList"); list.innerHTML = "";
    state.shortcuts.forEach((s, i) => {
      const card = el("div", "card");
      card.appendChild(cardHead(`#${i + 1}`, () => { state.shortcuts.splice(i, 1); renderShortcuts(); updatePreview(); }));
      const grid = el("div", "field-grid");
      grid.appendChild(labeledInput("المحفّز (trigger)", textInput(s.trigger, "sps", v => { s.trigger = v; updatePreview(); })));
      grid.appendChild(labeledInput("النص البديل", textInput(s.replacement, "شكرًا لتواصلك معنا", v => { s.replacement = v; updatePreview(); })));
      card.appendChild(grid);
      list.appendChild(card);
    });
  }
  $("#addShortcutBtn").addEventListener("click", () => {
    state.shortcuts.push({ id: nextId(), trigger: "", replacement: "" });
    renderShortcuts(); updatePreview();
  });

  /* ---------------------------------------------------------
     Symbols list
  --------------------------------------------------------- */
  function renderSymbols() {
    const list = $("#symbolsList"); list.innerHTML = "";
    state.symbols.forEach((s, i) => {
      const card = el("div", "card");
      card.appendChild(cardHead(`#${i + 1}`, () => { state.symbols.splice(i, 1); renderSymbols(); updatePreview(); }));
      const grid = el("div", "field-grid");
      grid.appendChild(labeledInput("العنوان", textInput(s.title, "أسهم", v => { s.title = v; updatePreview(); })));
      grid.appendChild(labeledInput("الأيقونة", textInput(s.icon, "@arrow", v => { s.icon = v; updatePreview(); })));
      card.appendChild(grid);
      const ta = document.createElement("textarea"); ta.rows = 2; ta.value = s.itemsText || "";
      ta.placeholder = "الرموز مفصولة بفاصلة، مثال: ← , → , ↑ , ↓";
      ta.addEventListener("input", () => { s.itemsText = ta.value; updatePreview(); });
      const w = el("label", "field field-wide"); const sp = el("span"); sp.textContent = "الرموز (items)";
      w.appendChild(sp); w.appendChild(ta); card.appendChild(w);
      list.appendChild(card);
    });
  }
  $("#addSymbolBtn").addEventListener("click", () => {
    state.symbols.push({ id: nextId(), title: "", icon: "", itemsText: "" });
    renderSymbols(); updatePreview();
  });

  /* ---------------------------------------------------------
     Variants list
  --------------------------------------------------------- */
  function renderVariants() {
    const list = $("#variantsList"); list.innerHTML = "";
    state.variants.forEach((v, i) => {
      const card = el("div", "card");
      card.appendChild(cardHead(`#${i + 1}`, () => { state.variants.splice(i, 1); renderVariants(); updatePreview(); }));
      const grid = el("div", "field-grid");
      grid.appendChild(labeledInput("الحرف", textInput(v.letter, "e", val => { v.letter = val; updatePreview(); })));
      grid.appendChild(labeledInput("البدائل (مفصولة بفاصلة)", textInput(v.altsText, "é,è,ê,ë", val => { v.altsText = val; updatePreview(); })));
      card.appendChild(grid);
      list.appendChild(card);
    });
  }
  $("#addVariantBtn").addEventListener("click", () => {
    state.variants.push({ id: nextId(), letter: "", altsText: "" });
    renderVariants(); updatePreview();
  });

  /* ---------------------------------------------------------
     Skin: orbs
  --------------------------------------------------------- */
  function renderOrbs() {
    const list = $("#orbsList"); list.innerHTML = "";
    state.skin.orbs.forEach((o, i) => {
      const card = el("div", "card");
      card.appendChild(cardHead(`orb #${i + 1}`, () => { state.skin.orbs.splice(i, 1); renderOrbs(); updatePreview(); }));
      const grid = el("div", "field-grid cols-3");
      grid.appendChild(labeledInput("اللون", colorInput(o.color, v => { o.color = v; updatePreview(); })));
      grid.appendChild(labeledInput("x (0–1)", numberInput(o.x, v => { o.x = v; updatePreview(); }, { step: 0.05, min: -1, max: 2 })));
      grid.appendChild(labeledInput("y (0–1)", numberInput(o.y, v => { o.y = v; updatePreview(); }, { step: 0.05, min: -1, max: 2 })));
      grid.appendChild(labeledInput("r (نصف القطر)", numberInput(o.r, v => { o.r = v; updatePreview(); }, { step: 0.05, min: 0, max: 2 })));
      card.appendChild(grid);
      list.appendChild(card);
    });
  }
  $("#addOrbBtn").addEventListener("click", () => {
    state.skin.orbs.push({ id: nextId(), color: "#e8b24d", x: 0.8, y: 0.1, r: 0.4 });
    renderOrbs(); updatePreview();
  });

  /* ---------------------------------------------------------
     Skin: per-key styles
  --------------------------------------------------------- */
  function renderKeyStyles() {
    const list = $("#keysList"); list.innerHTML = "";
    state.skin.keys.forEach((k, i) => {
      const card = el("div", "card");
      card.appendChild(cardHead(`#${i + 1}`, () => { state.skin.keys.splice(i, 1); renderKeyStyles(); updatePreview(); }));
      const grid = el("div", "field-grid");
      grid.appendChild(labeledInput("المحدد (selector)", textInput(k.selector, "* أو enter أو key:ا", v => { k.selector = v; updatePreview(); })));
      grid.appendChild(labeledInput("Material", selectInput([["glass", "glass"], ["solid", "solid"]], k.material, v => { k.material = v; updatePreview(); })));
      grid.appendChild(labeledInput("لون النص", colorInput(k.textColor, v => { k.textColor = v; updatePreview(); })));
      grid.appendChild(labeledInput("Press", selectInput([["jelly", "jelly"], ["none", "none"]], k.press, v => { k.press = v; updatePreview(); })));
      grid.appendChild(labeledInput("خلفية مخصّصة (اختياري)", colorInput(k.background || "#1c252e", v => { k.background = v; updatePreview(); })));
      grid.appendChild(checkboxField("توهّج (glow)", k.glow, v => { k.glow = v; updatePreview(); }));
      grid.appendChild(labeledInput("شكل مخصّص (اختياري، مثال pill)", textInput(k.shape, "pill", v => { k.shape = v; updatePreview(); })));
      grid.appendChild(labeledInput("Label مخصّص (اختياري)", textInput(k.label, "", v => { k.label = v; updatePreview(); })));
      card.appendChild(grid);
      list.appendChild(card);
    });
  }
  $("#addKeyStyleBtn").addEventListener("click", () => {
    state.skin.keys.push({ id: nextId(), selector: "*", material: "glass", textColor: "#eef1f0", press: "jelly", background: "", glow: false, shape: "", label: "" });
    renderKeyStyles(); updatePreview();
  });

  /* ---------------------------------------------------------
     Scalar field bindings
  --------------------------------------------------------- */
  function bindScalar(selector, onInput, isCheckbox = false) {
    const e = $(selector);
    e.addEventListener(isCheckbox ? "change" : "input", () => {
      onInput(isCheckbox ? e.checked : e.value);
      updatePreview();
    });
    return e;
  }
  bindScalar("#f_id", v => state.id = v);
  bindScalar("#f_name", v => state.name = v);
  bindScalar("#f_version", v => state.version = v);
  bindScalar("#f_author", v => state.author = v);
  bindScalar("#f_icon", v => state.icon = v);
  bindScalar("#f_description", v => state.description = v);

  bindScalar("#t_seed", v => state.theme.seed = v);
  bindScalar("#t_mode", v => state.theme.mode = v);
  const shapeCustomInput = $("#t_shape_custom");
  bindScalar("#t_shape", v => {
    state.theme.shape = v;
    shapeCustomInput.hidden = v !== "__custom";
  });
  bindScalar("#t_shape_custom", v => state.theme.shapeCustom = v);
  bindScalar("#t_accent", v => state.theme.accent = v);
  bindScalar("#t_accentText", v => state.theme.accentText = v);

  bindScalar("#s_keyHeight", v => state.settings.keyHeight = parseFloat(v) || 0);
  bindScalar("#s_numberRow", v => state.settings.numberRow = v, true);

  bindScalar("#k_bg1", v => state.skin.bg1 = v);
  bindScalar("#k_bg2", v => state.skin.bg2 = v);
  bindScalar("#k_angle", v => state.skin.angle = parseFloat(v) || 0);

  bindScalar("#c_material", v => state.skin.chipsMaterial = v);
  bindScalar("#c_textColor", v => state.skin.chipsTextColor = v);

  $("#advancedJson").addEventListener("input", (e) => { state.advancedRaw = e.target.value; updatePreview(); });

  /* ---------------------------------------------------------
     Build final plugin JSON
  --------------------------------------------------------- */
  function buildPluginObject() {
    const out = {};
    if (state.id.trim()) out.id = state.id.trim();
    if (state.name.trim()) out.name = state.name.trim();
    if (state.version.trim()) out.version = state.version.trim();
    if (state.author.trim()) out.author = state.author.trim();
    if (state.description.trim()) out.description = state.description.trim();
    if (state.icon.trim()) out.icon = state.icon.trim();

    if (state.actions.length) {
      out.actions = state.actions.map(a => {
        const o = { title: a.title || "", icon: a.icon || "", type: a.type };
        if (a.type === "insert") o.text = a.text || "";
        if (a.type === "transform") {
          o.transform = a.transform || "calc";
          if (o.transform === "wrap") { o.prefix = a.prefix || ""; o.suffix = a.suffix || ""; }
        }
        if (a.type === "key") o.key = a.key || "";
        o.pinned = !!a.pinned;
        return o;
      });
    }

    if (state.shortcuts.length) {
      const map = {};
      state.shortcuts.forEach(s => { if (s.trigger && s.trigger.trim()) map[s.trigger.trim()] = s.replacement || ""; });
      if (Object.keys(map).length) out.shortcuts = map;
    }

    if (state.symbols.length) {
      out.symbols = state.symbols.map(s => ({
        title: s.title || "",
        icon: s.icon || "",
        items: (s.itemsText || "").split(/[,\n]/).map(x => x.trim()).filter(Boolean)
      }));
    }

    out.theme = {
      seed: state.theme.seed,
      mode: state.theme.mode,
      shape: state.theme.shape === "__custom" ? (state.theme.shapeCustom || "") : state.theme.shape,
      colors: { accent: state.theme.accent, accentText: state.theme.accentText }
    };

    out.settings = { key_height_dp: state.settings.keyHeight, show_number_row: !!state.settings.numberRow };

    if (state.variants.length) {
      const map = {};
      state.variants.forEach(v => {
        if (v.letter && v.letter.trim()) {
          map[v.letter.trim()] = (v.altsText || "").split(",").map(x => x.trim()).filter(Boolean);
        }
      });
      if (Object.keys(map).length) out.variants = map;
    }

    const skin = {
      keyboard: {
        background: { colors: [state.skin.bg1, state.skin.bg2], angle: state.skin.angle },
        orbs: state.skin.orbs.map(o => ({ color: o.color, x: o.x, y: o.y, r: o.r }))
      },
      keys: {},
      chips: { material: state.skin.chipsMaterial, textColor: state.skin.chipsTextColor }
    };
    state.skin.keys.forEach(k => {
      if (!k.selector || !k.selector.trim()) return;
      const style = { material: k.material, textColor: k.textColor, press: k.press };
      if (k.background) style.background = k.background;
      if (k.glow) style.glow = true;
      if (k.shape && k.shape.trim()) style.shape = k.shape.trim();
      if (k.label && k.label.trim()) style.label = k.label.trim();
      skin.keys[k.selector.trim()] = style;
    });
    out.skin = skin;

    return out;
  }

  function deepMerge(target, source) {
    if (Array.isArray(source)) return source.slice();
    if (source && typeof source === "object") {
      const base = (target && typeof target === "object" && !Array.isArray(target)) ? target : {};
      const result = Object.assign({}, base);
      Object.keys(source).forEach(k => { result[k] = deepMerge(base[k], source[k]); });
      return result;
    }
    return source;
  }

  function buildFinalObject() {
    const base = buildPluginObject();
    const raw = (state.advancedRaw || "").trim();
    if (!raw) return base;
    try {
      const override = JSON.parse(raw);
      return deepMerge(base, override);
    } catch (e) {
      return base; // invalid override JSON is ignored silently in the preview
    }
  }

  /* ---------------------------------------------------------
     Preview + validity indicator
  --------------------------------------------------------- */
  function updatePreview() {
    const json = JSON.stringify(buildFinalObject(), null, 2);
    $("#jsonPreview").textContent = json;
  }

  /* ---------------------------------------------------------
     Tabs
  --------------------------------------------------------- */
  const titles = {
    info: "معلومات البلاجن", actions: "الإجراءات", shortcuts: "الاختصارات",
    symbols: "الرموز", theme: "الثيم", settings: "الإعدادات",
    variants: "البدائل", skin: "المظهر (Skin)", advanced: "متقدّم وتصدير"
  };
  $$(".key-tab").forEach(btn => {
    btn.addEventListener("click", () => {
      $$(".key-tab").forEach(b => b.classList.remove("is-active"));
      $$(".panel").forEach(p => p.classList.remove("is-active"));
      btn.classList.add("is-active");
      const section = btn.dataset.section;
      $(`.panel[data-panel="${section}"]`).classList.add("is-active");
      $("#sectionTitle").textContent = titles[section] || "";
      if (section === "advanced") updatePreview();
    });
  });

  /* ---------------------------------------------------------
     Toast
  --------------------------------------------------------- */
  let toastTimer = null;
  function toast(msg) {
    const t = $("#toast");
    t.innerHTML = ""; const span = el("span"); span.textContent = msg; t.appendChild(span);
    t.classList.add("show");
    clearTimeout(toastTimer);
    requestAnimationFrame(() => t.querySelector("span").classList.add("show"));
    toastTimer = setTimeout(() => { t.classList.remove("show"); }, 2200);
  }

  /* ---------------------------------------------------------
     Export actions
  --------------------------------------------------------- */
  $("#downloadBtn").addEventListener("click", () => {
    const json = JSON.stringify(buildFinalObject(), null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = (state.id.trim() || "plugin") + ".json";
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
    toast("تم تحميل الملف");
  });

  $("#copyBtn").addEventListener("click", async () => {
    const json = JSON.stringify(buildFinalObject(), null, 2);
    try {
      await navigator.clipboard.writeText(json);
      toast("تم نسخ الـ JSON");
    } catch (e) {
      toast("تعذّر النسخ — انسخ يدويًا من المعاينة");
    }
  });

  /* ---------------------------------------------------------
     Import existing plugin.json
  --------------------------------------------------------- */
  $("#importFile").addEventListener("change", (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result);
        if (parsed.id) { state.id = parsed.id; $("#f_id").value = parsed.id; }
        if (parsed.name) { state.name = parsed.name; $("#f_name").value = parsed.name; }
        if (parsed.version) { state.version = parsed.version; $("#f_version").value = parsed.version; }
        if (parsed.author) { state.author = parsed.author; $("#f_author").value = parsed.author; }
        if (parsed.description) { state.description = parsed.description; $("#f_description").value = parsed.description; }
        if (parsed.icon) { state.icon = parsed.icon; $("#f_icon").value = parsed.icon; }
        if (parsed.theme) {
          if (parsed.theme.seed) { state.theme.seed = parsed.theme.seed; $("#t_seed").value = parsed.theme.seed; }
          if (parsed.theme.mode) { state.theme.mode = parsed.theme.mode; $("#t_mode").value = parsed.theme.mode; }
          if (parsed.theme.colors) {
            if (parsed.theme.colors.accent) { state.theme.accent = parsed.theme.colors.accent; $("#t_accent").value = parsed.theme.colors.accent; }
            if (parsed.theme.colors.accentText) { state.theme.accentText = parsed.theme.colors.accentText; $("#t_accentText").value = parsed.theme.colors.accentText; }
          }
        }
        if (parsed.settings) {
          if (parsed.settings.key_height_dp != null) { state.settings.keyHeight = parsed.settings.key_height_dp; $("#s_keyHeight").value = parsed.settings.key_height_dp; }
          if (parsed.settings.show_number_row != null) { state.settings.numberRow = parsed.settings.show_number_row; $("#s_numberRow").checked = parsed.settings.show_number_row; }
        }
        state.advancedRaw = JSON.stringify(parsed, null, 2);
        $("#advancedJson").value = state.advancedRaw;
        updatePreview();
        $('.key-tab[data-section="advanced"]').click();
        toast("تم الاستيراد — الملف الكامل موجود في تبويب \"متقدّم\" كطبقة Override");
      } catch (err) {
        toast("الملف مش JSON صالح");
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  });

  /* ---------------------------------------------------------
     Sample data
  --------------------------------------------------------- */
  $("#loadSampleBtn").addEventListener("click", () => {
    state.id = "com.hassan.sample"; state.name = "بلاجن تجريبي"; state.version = "1.0.0";
    state.author = "Hassan"; state.description = "مثال يوضح كل أقسام البلاجن"; state.icon = "@rocket";
    $("#f_id").value = state.id; $("#f_name").value = state.name; $("#f_version").value = state.version;
    $("#f_author").value = state.author; $("#f_description").value = state.description; $("#f_icon").value = state.icon;

    state.actions = [
      { id: nextId(), title: "التاريخ", icon: "@calendar", type: "insert", text: "{date:yyyy-MM-dd}", transform: "calc", prefix: "", suffix: "", key: "", pinned: true },
      { id: nextId(), title: "تكبير أول حرف", icon: "@upper", type: "transform", text: "", transform: "upper", prefix: "", suffix: "", key: "", pinned: false },
      { id: nextId(), title: "تحديد الكل", icon: "@select", type: "key", text: "", transform: "calc", prefix: "", suffix: "", key: "select_all", pinned: false }
    ];
    state.shortcuts = [{ id: nextId(), trigger: "sps", replacement: "شكرًا لتواصلك معنا" }];
    state.symbols = [{ id: nextId(), title: "أسهم", icon: "@arrow", itemsText: "←, →, ↑, ↓" }];
    state.variants = [{ id: nextId(), letter: "ه", altsText: "هـ, ة" }];
    state.skin.orbs = [{ id: nextId(), color: "#e8b24d", x: 0.85, y: 0.05, r: 0.45 }];
    state.skin.keys = [
      { id: nextId(), selector: "*", material: "glass", textColor: "#eef1f0", press: "jelly", background: "", glow: false, shape: "", label: "" },
      { id: nextId(), selector: "space", material: "glass", textColor: "#9aa7ac", press: "jelly", background: "", glow: false, shape: "pill", label: "مسافة" }
    ];

    renderActions(); renderShortcuts(); renderSymbols(); renderVariants(); renderOrbs(); renderKeyStyles();
    updatePreview();
    toast("تم تحميل مثال جاهز");
  });

  /* ---------------------------------------------------------
     Reset
  --------------------------------------------------------- */
  $("#resetBtn").addEventListener("click", () => {
    if (!confirm("هل تريد تصفير كل البيانات؟")) return;
    location.reload();
  });

  /* ---------------------------------------------------------
     Service worker (offline support once installed)
  --------------------------------------------------------- */
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("service-worker.js").catch(() => {});
    });
  }

  /* ---------------------------------------------------------
     Init
  --------------------------------------------------------- */
  renderActions(); renderShortcuts(); renderSymbols(); renderVariants(); renderOrbs(); renderKeyStyles();
  updatePreview();
})();
